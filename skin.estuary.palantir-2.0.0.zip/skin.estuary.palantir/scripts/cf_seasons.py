# -*- coding: utf-8 -*-
"""Palantir Flix: obtiene la ruta de temporadas de una serie de Palantir sin reproducir nada.

Palantir abre las series que sigues con la acción 'play_mis_serieS', que reproduce directamente
el siguiente capítulo. Para la ficha cambiamos esa acción por 'listado_temporadaS' (listar temporadas)
y guardamos la original para el botón "Continuar viendo".
"""
import ast
import base64
import sys
from urllib import parse

import xbmcgui

PREFIX = "plugin://plugin.video.palantir3/?"


def p3decode(value):
    v = parse.unquote(value).encode().replace(b"?", b"")
    n = len(v)
    pad = (4 - n % 4) % 4
    k = int((n + pad) / 4)
    return base64.b64decode(v[:k][::-1] + v[k:][::-1] + b"=" * pad).decode("utf-8")


def p3encode(text):
    v = base64.b64encode(text.encode())
    k = int(len(v) / 4)
    v = v.replace(b"=", b"")
    return parse.quote(v[:k][::-1] + v[k:][::-1])


def main():
    win = xbmcgui.Window(10000)
    path = sys.argv[1] if len(sys.argv) > 1 else ""
    if not path.startswith(PREFIX):
        win.setProperty("cf.seasonspath", path)
        return
    query = path[len(PREFIX):]
    encoded, _, extra = query.partition("&")
    try:
        item = ast.literal_eval(p3decode(encoded))
    except Exception:
        win.setProperty("cf.seasonspath", path)
        return
    if item.get("action") == "play_mis_serieS":
        win.setProperty("cf.nextpath", path)
        item["action"] = "listado_temporadaS"
    if item.get("action") == "listado_temporadaS":
        win.setProperty("cf.seasonspath", PREFIX + p3encode(repr(item)))
    else:
        win.setProperty("cf.seasonspath", path)


if __name__ == "__main__":
    main()
