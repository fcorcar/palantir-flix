# Palantir Flix: borra de la caché de Palantir los widgets que usa la skin, para que se generen
# con los parámetros de la skin (sin tarjeta "Más" y con paginación propia).
import sqlite3
import xbmcvfs

IDS = ['WidgetPeliculasNoFinalizadas', 'WidgetPeliculasRecomendadas', 'WidgetPelisWatchlist', 'WidgetSeriesRecomendadas', 'WidgetSeriesSeguimiento', 'WidgetSeriesWatchlist', 'WidgetTop10Pelis', 'WidgetTop10Series']


def main():
    path = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.palantir3/cache.db")
    if not xbmcvfs.exists(path):
        return
    try:
        con = sqlite3.connect(path, timeout=10)
        con.execute("DELETE FROM simplecache WHERE id IN (%s)" % ",".join("?" * len(IDS)), IDS)
        con.execute("DELETE FROM simplecache WHERE id LIKE 'WidgetFlix%'")
        con.commit()
        con.close()
    except Exception:
        pass


if __name__ == "__main__":
    main()
